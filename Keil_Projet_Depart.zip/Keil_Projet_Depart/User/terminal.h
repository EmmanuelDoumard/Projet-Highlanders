#ifndef TERMINAL_H
#define TERMINAL_H

void init_terminal(void);
int tprintf (const  char *fmt, ...);
void terminal_puts(const char* str);

#endif // TERMINAL_H
